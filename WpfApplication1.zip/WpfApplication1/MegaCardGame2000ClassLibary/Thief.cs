﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegaCardGame2000ClassLibary
{
   public class Thief : PlayerCharacter
    {
       
        
        public int Thief(int p, int p_2, string p_3)
        {
            throw new NotImplementedException();
        }

    }
}
