﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegaCardGame2000ClassLibary
{
   public class Warrior : PlayerCharacter
    {
        

        public int Warrior(int p, int p_2, string p_3)
        {
            throw new NotImplementedException();
        }

    }
}
