﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegaCardGame2000ClassLibary
{
   public class NormalAttack : Attack
    {
        public int GetAttackResult()
        {
            throw new NotImplementedException();
        }
    }
}
