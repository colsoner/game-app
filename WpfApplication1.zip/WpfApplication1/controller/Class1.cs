﻿using System;

namespace MCGController
{
    public class Class1
    {
    }
}
